package com.employee.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class EmployeeDTO {
	
	private int userId;
	private int id;
	private String title;
	private String body;

}
