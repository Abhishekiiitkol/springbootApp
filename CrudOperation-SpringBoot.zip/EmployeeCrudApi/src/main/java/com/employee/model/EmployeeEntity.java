package com.employee.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Entity
@Table(name="TBL_EMPLOYEES")
@Data
public class EmployeeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(notes = "The database generated Employee ID")
    private Long id;
    
    @Column(name="first_name")
    @ApiModelProperty(notes = "Employee First Name")
    private String firstName;
    
    @Column(name="last_name")
    @ApiModelProperty(notes = "Employee Last Name")
    private String lastName;
    
    @Column(name="email", nullable=false, length=200)
    @ApiModelProperty(notes = "Employee Email id")
    private String email;
    
    @Override
    public String toString() {
        return "EmployeeEntity [id=" + id + ", firstName=" + firstName + 
                ", lastName=" + lastName + ", email=" + email   + "]";
    }
}