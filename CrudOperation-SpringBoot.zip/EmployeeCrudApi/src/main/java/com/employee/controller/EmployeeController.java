package com.employee.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.employee.exception.RecordNotFoundException;
import com.employee.model.EmployeeDTO;
import com.employee.model.EmployeeEntity;
import com.employee.service.EmployeeService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
 
@RestController
@RequestMapping("/employees")
@Slf4j
@Api(value="Employee Rest API", description = "Employee REST API")
public class EmployeeController
{
	Logger logger = LoggerFactory.getLogger(EmployeeController.class);
	
    @Autowired
    EmployeeService service;
 
    // implemented slf4j loggers 
    @ApiOperation(value = "Get Employee details by Name")
    @GetMapping("/{name}")
    public String greetings(@PathVariable String name) {
    	log.info("Requested {} ", name);
    	String response = "Hi"+name+"Welcome to ITC Infotech Pvt. Ltd.";
    	log.info("Response {}", response);
    	return response;
    }
    
    @ApiOperation(value = "Get All Employee details")
    @GetMapping
    public ResponseEntity<List<EmployeeEntity>> getAllEmployees() {
    	log.debug("showing list of employees");
        List<EmployeeEntity> list = service.getAllEmployees();
        log.debug("Employees list {}", list);
        return new ResponseEntity<List<EmployeeEntity>>(list, new HttpHeaders(), HttpStatus.OK);
    }
 
    @ApiOperation(value = "Get Employee details by ID")
    @GetMapping("/{id}")
    public ResponseEntity<EmployeeEntity> getEmployeeById(@PathVariable("id") Long id)
                                                    throws RecordNotFoundException {
        EmployeeEntity entity = service.getEmployeeById(id);
 
        return new ResponseEntity<EmployeeEntity>(entity, new HttpHeaders(), HttpStatus.OK);
    }
 
    @ApiOperation(value = "Update/insert Employee details")
    @PostMapping
    public ResponseEntity<EmployeeEntity> createOrUpdateEmployee(EmployeeEntity employee)
                                                    throws RecordNotFoundException {
        EmployeeEntity updated = service.createOrUpdateEmployee(employee);
        return new ResponseEntity<EmployeeEntity>(updated, new HttpHeaders(), HttpStatus.OK);
    }
 
    @ApiOperation(value = "Delete Employee by ID")
    @DeleteMapping("/{id}")
    public HttpStatus deleteEmployeeById(@PathVariable("id") Long id)
                                                    throws RecordNotFoundException {
        service.deleteEmployeeById(id);
        return HttpStatus.FORBIDDEN;
    }
    
    @ApiOperation(value = "REST Template Api")
    @GetMapping("/restTemplate")
    public ResponseEntity<EmployeeDTO> gerRestTemplate() {
    	final String uri = "https://jsonplaceholder.typicode.com/posts/1";
    	RestTemplate restTemplate = new RestTemplate();
    	
    	EmployeeDTO empDto = restTemplate.getForObject(uri, EmployeeDTO.class);
    	
    	return new ResponseEntity<EmployeeDTO>(empDto, new HttpHeaders(), HttpStatus.OK);
    }
    
    
 
}