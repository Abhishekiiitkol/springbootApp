INSERT INTO 
	TBL_EMPLOYEES (first_name, last_name, email) 
VALUES
  	('Abhishek', 'Kumar', 'abhishek.iiikol@gmail.com'),
  	('Rahul', 'gupta', 'rahul.gupta@gmail.com'),
  	('Manish', 'Singh', 'msingh@gmail.com'),
  	('Vara', 'Prasad', 'vara.prasad@gmail.com');